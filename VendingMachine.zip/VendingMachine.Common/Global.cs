﻿namespace VendingMachine.Common {
    public static class Global {
        public static IViewFactory ViewFactory { get; set; }
    }
}
