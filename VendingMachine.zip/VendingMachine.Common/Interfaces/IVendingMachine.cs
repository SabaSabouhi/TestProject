﻿namespace VendingMachine.Common {
    public interface IVendingMachine {
        void Initialize();
    }
}
