﻿using VendingMachine.Common;

namespace VendingMachine {

    public partial class MainWindow:IView {
        public MainWindow() {
            InitializeComponent();
        }
    }
}
