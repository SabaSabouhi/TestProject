﻿using VendingMachine.Common;

namespace VendingMachine.Views {
    public partial class ProductionView: IView {
        public ProductionView() {
            InitializeComponent();
        }
    }
}
